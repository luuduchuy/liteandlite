<?php
/**
 * Underscore.js template.
 *
 * @package fusion-builder
 */

?>
<script type="text/template" id="fusion-builder-block-module-image-frame-preview-template">

	<h4 class="fusion_module_title"><span class="fusion-module-icon {{ fusionAllElements[element_type].icon }}"></span>{{ fusionAllElements[element_type].name }}</h4>

	<#
	var elementContent = params.element_content;

	if ( 'undefined' !== typeof elementContent ) {
		if ( elementContent.indexOf( '&lt;img' ) >= 0 ) {
			imagePreview = jQuery( '<div></div>' ).html( elementContent ).text();
		} else if ( elementContent.indexOf( '<img' ) >= 0 || elementContent.indexOf( 'fusion_dynamic_data_icon' ) >= 0 ) {
			imagePreview =  jQuery( '<div></div>' ).html( elementContent ).html();
		} else {
			imagePreview = '<img src="' + elementContent + '" />';
		}
	}
	#>

	{{{ imagePreview }}}

</script>
